from hardware.hardware import HARDWARE
from operating_system.loaders.AbstractLoaderAlgorithm import AbstractLoaderAlgorithm

class FirstFit(AbstractLoaderAlgorithm):
    
    def __init__(self, kernel):
        super().__init__(kernel)
    
    def load(self, data):
        """Da la direccion de Inincio de la memoria"""
        data_size = len(data)
        start_index = self._find_memory_space(data_size)
        
        if start_index is None:
            raise RuntimeError("No hay suficiente espacio en memoria para cargar el programa.")
        
        # guarda la informacion en memoria
        for i, instruction in enumerate(data):
            HARDWARE.memory.write(start_index + i, instruction)

        return start_index

    def _find_memory_space(self, program_size):
        """
        Este es el metodo que se encarga de encotrar un espacio de memoria libre segun FF 
        """
        memory_range=range(HARDWARE.memory.size - program_size + 1)
        
        for i in memory_range:
            if self._is_block_free(i, program_size):
                return i
        return None
    
    def _is_block_free(self, start_index, block_size):
        """
        comprueba si un bloque de memoria es libre a partir start_index y block_size
        """
        return all(HARDWARE.memory.read(start_index + j) == "" for j in range(block_size))