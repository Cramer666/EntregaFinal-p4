
class AbstractLoaderAlgorithm:
    def __init__(self,kernel):
        self._kernel=kernel

    @property
    def kernel(self):
        return self.__kernel
    
    def load(self, program):
        pass
    