from operating_system.loaders.AbstractLoaderAlgorithm import AbstractLoaderAlgorithm

class WorstFit(AbstractLoaderAlgorithm):    
    
    def __init__(self, kernel):
        super().__init__(kernel)

    def load(self, data):
       pass
    