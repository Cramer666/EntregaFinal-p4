from utilities.priority_queue import PriorityQueue

from operating_system.scheduling.preemptive.preemptive_scheduler import PreemptiveSchedulerAlgorithm

class LRTFSchedulingAlgorithm(PreemptiveSchedulerAlgorithm):
    """ Implementation of Longest Running Time First Scheduling Algorithm. """

    # TODO (3) Complete the class

    def __init__(self, kernel, quantum):
        super().__init__(kernel, quantum)
        self._ready_priority_Queue=PriorityQueue()
    
    @property
    def next_process_id(self):
        if not self._ready_priority_Queue.is_empty:
            return self._ready_priority_Queue.front
        return None
    
    def move_to_ready(self, pid, pcb):
        remaining_time=pcb.remaining_time
        priority = remaining_time
        self._ready_priority_Queue.enqueue(pid,priority)
    
    def move_to_running(self, pid, pcb):
        if not self._ready_priority_Queue.is_empty:
            self._ready_priority_Queue.dequeue()
        else:
            print("La cola de listos está vacía.")
    
    def move_to_waiting(self, pid, pcb):
        pass