from hardware.hardware import HARDWARE
from operating_system.loaders.best_fit import BestFit
from operating_system.loaders.first_fit import FirstFit
from operating_system.loaders.worst_fit import WorstFit

class Loader:

    def __init__(self, kernel, loader_algorithm):
        self.__kernel = kernel
        self.__available_loader_algorithms = {
            'FF': FirstFit(kernel),
            'BF':  BestFit(kernel),
            'WF':  WorstFit(kernel),
        }
        self.__current_algorithm_name=loader_algorithm
        self.__current_algorithm =self.__available_loader_algorithms[loader_algorithm]
        
    @property
    def current_algrithm(self):
        return self.__current_algorithm
    
    @property
    def current_algorithm_name(self):
        return self.__current_algorithm_name
    
    @current_algorithm_name.setter
    def current_algorithm_name(self, value):
        if(value not in self.__available_loader_algorithms):
            raise RuntimeError("No existe ningun algoritmo de asignacion de memoria que se llame: "+ value)
        self.__current_algorithm_name=value
        self.__current_algorithm=self.__available_loader_algorithms[value]
        
    @property
    def current_algorithm(self):
        return self.__current_algorithm
    @property
    def kernel(self):
        return self.kernel
    
    
    def load(self, data):
        return self.current_algorithm.load(data)
    
    def unload(self, pcb):
        """
        Remove a program that is loaded into memory from the memory. 
        The PCB is received and used to know where the program is
        stored in memory.
        """
        for i in range(pcb.memory_start, pcb.memory_end):
            HARDWARE.memory.write(i, '')
